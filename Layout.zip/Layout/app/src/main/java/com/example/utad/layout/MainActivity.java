package com.example.utad.layout;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        GameData aux = new GameData("Horizon", "....", "2022", "Sony");
        GameData.m_gameDataList.add(aux);
        aux = new GameData("Forza", "....", "2021", "Micro");
        GameData.m_gameDataList.add(aux);

    }
    public void GoToDetail(View v){

    }
    public void itemClicked(long id){
        Intent intent = new Intent(this, GameDetailActivity.class);
        intent.putExtra("gameId", id);
        startActivity(intent);
    }
}
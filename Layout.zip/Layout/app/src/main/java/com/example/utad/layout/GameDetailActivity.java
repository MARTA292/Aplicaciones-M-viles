package com.example.utad.layout;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class GameDetailActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_detail);

        GameDetailFragment fragment = (GameDetailFragment) getSupportFragmentManager().findFragmentById(R.id.game_detail_fragment);
        fragment.setGame(getIntent().getIntExtra("gameId", 0));
    }
}

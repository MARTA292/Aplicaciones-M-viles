package com.example.utad.layout;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class GameDetailFragment extends Fragment {
    private long m_gameId;

    public GameDetailFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_game_detail, container, false);
    }

    public void onStart(){
        super.onStart();
        View v = getView();

        if(v != null){
            ((TextView)v.findViewById(R.id.name)).setText(GameData.m_gameDataList.get((int)m_gameId).m_title);
            ((TextView)v.findViewById(R.id.description)).setText(GameData.m_gameDataList.get((int)m_gameId).m_description);
            ((TextView)v.findViewById(R.id.year)).setText(GameData.m_gameDataList.get((int)m_gameId).m_year);
            ((TextView)v.findViewById(R.id.company)).setText(GameData.m_gameDataList.get((int)m_gameId).m_company);
        }
    }

    public void setGame(long id){
        m_gameId = id;
    }
}
package com.example.utad.recyclerview;

public class VideoconsoleData {
    String consoleName = "";
    String companyName = "";
    int imageResourceId;
    public static final VideoconsoleData[] Videoconsole = {
            new VideoconsoleData("Xbox", "Microsoft", R.drawable.xbox),
            new VideoconsoleData("PS4", "Sony", R.drawable.ps4),
            new VideoconsoleData("WiiU", "Nintendo", R.drawable.ps4)
    };
    private VideoconsoleData(String consoleName, String companyName, int imageResourceId)
    {
        this.consoleName = consoleName;
        this.companyName = companyName;
        this.imageResourceId = imageResourceId;
    }

}

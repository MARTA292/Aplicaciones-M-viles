package com.example.utad.recyclerview;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class VideoconsoleRecycleViewAdapter extends RecyclerView.Adapter<VideoconsoleRecycleViewAdapter.MyViewHolder>{
    private VideoconsoleData[] mDataset;

    public VideoconsoleRecycleViewAdapter(VideoconsoleData[] myDataset) {
        mDataset = myDataset;
    }
    @Override
    public VideoconsoleRecycleViewAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LinearLayout v = (LinearLayout) LayoutInflater.from(parent.getContext()).inflate(R.layout.videoconsole_item_custom, parent,
        false);
        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        ((TextView)holder.linearView.findViewById(R.id.videoconsoleName)).setText(mDataset[position].consoleName);
        ((TextView)holder.linearView.findViewById(R.id.companyName)).setText(mDataset[position].companyName);
    }

    @Override
    public int getItemCount() {
        return mDataset.length;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public LinearLayout linearView;
        public MyViewHolder(LinearLayout v) {
            super(v);
            linearView = v;
        }
    }

}

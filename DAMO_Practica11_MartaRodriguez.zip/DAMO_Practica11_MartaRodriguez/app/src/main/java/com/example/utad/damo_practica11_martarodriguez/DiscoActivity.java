package com.example.utad.damo_practica11_martarodriguez;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DiscoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disco);
    }
}
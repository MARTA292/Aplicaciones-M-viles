package com.example.utad.damo_practica11_martarodriguez;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.ListFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class ArtistListFragment extends ListFragment {

    public ArtistListFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        String names[] = new String[Artista.m_artistaList.size()];
        for (int i = 0; i < Artista.m_artistaList.size(); i++){
            names[i] = Artista.m_artistaList.get(i).m_nombre;
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(inflater.getContext(), android.R.layout.simple_list_item_1, names);
        setListAdapter(adapter);
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_artist_list, container, false);
    }
    /*
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        String names[] = new String[DiscoData.m_discoDataList.size()];
        for (int i = 0; i < DiscoData.m_discoDataList.size(); i++){
            names[i] = DiscoData.m_discoDataList.get(i).m_title;
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(inflater.getContext(), android.R.layout.simple_list_item_1, names);
        setListAdapter(adapter);
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_disco_list, container, false);
    }
    */
    static interface Listener{
        void itemClicked(long id);
    }

    private Listener m_listener;

    @Override
    public void onAttach(Context context){
        super.onAttach(context);
        m_listener = (Listener) context;
    }
    @Override
    public void onListItemClick (ListView list, View item, int position, long id){
        if (m_listener != null){
            m_listener.itemClicked(id);
        }
    }
}
package com.example.utad.damo_practica11_martarodriguez;

import java.util.ArrayList;

public class Artista {
    public String m_nombre;
    public int m_imagen;

    public static final ArrayList<Artista> m_artistaList = new ArrayList<>();

    public Artista(String nombre, int imagen) {
        this.m_nombre = nombre;
        this.m_imagen = imagen;
    }
}

package com.example.utad.damo_practica11_martarodriguez;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements ArtistListFragment.Listener {
    private ArrayList<Artista> artistas;
    private ArrayList<Disco> discos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        artistas = getArtistas();
        setContentView(R.layout.activity_main);
    }
    @Override
    public void itemClicked(long id)
    {
        Intent intent = new Intent(this, DiscoActivity.class);
        if (id == 0) {
            Log.d("Item Clicked", "0");
            discos = getDiscoColdPlay();
        }else if (id == 1) {
            Log.d("Item Clicked", "1");
            //changeOffspring(parent);
        }else if (id == 2) {
            Log.d("Item Clicked", "2");
            //changePapaRoach(parent);
        }else if (id == 3) {
            Log.d("Item Clicked", "3");
            //changePeppers(parent);
        }
        //intent.putExtra("discoArtistaId", id);
        startActivity(intent);
    }
    public ArrayList<Artista> getArtistas(){
        Artista.m_artistaList.add(new Artista("ColdPlay",0));
        Artista.m_artistaList.add(new Artista("The Offspring",0));
        Artista.m_artistaList.add(new Artista("Papa Roach",0));
        Artista.m_artistaList.add(new Artista("Red Hot Chili Peppers",0));
        return Artista.m_artistaList;
    }

    public ArrayList<Disco> getDiscoColdPlay(){
        Disco.m_discoList.add(new Disco("Parachutes", "ColdPlay", "Capitol Records", 2000, 0));
        Disco.m_discoList.add(new Disco("A Rush of Blood to the Head", "ColdPlay", "Capitol Records", 2002, 0));
        Disco.m_discoList.add(new Disco("X&Y", "ColdPlay", "Capitol Records", 2008, 0));
        Disco.m_discoList.add(new Disco("Mylo Xyloto", "ColdPlay", "Capitol Records", 2011, 0));
        Disco.m_discoList.add(new Disco("Ghost Stories", "ColdPlay", "Parlophone", 2014, 0));
        Disco.m_discoList.add(new Disco("Everyday Life", "ColdPlay", "Parlophone", 2021, 0));
        return Disco.m_discoList;
    }

    public ArrayList<Disco> getDiscoOffSpring(){
        Disco.m_discoList.add(new Disco("Smash", "The Offspring", "Epitaph Records", 1994, 0));
        Disco.m_discoList.add(new Disco("Ixnay on the Hombre", "The Offspring", "Columbia Records", 1997, 0));
        Disco.m_discoList.add(new Disco("Americana", "The Offspring", "Columbia Records", 1998, 0));
        Disco.m_discoList.add(new Disco("Splinter", "The Offspring", "Columbia Records", 2003, 0));
        Disco.m_discoList.add(new Disco("Rise and Fall, Rage and Grace", "The Offspring", "Columbia Records", 2008, 0));
        Disco.m_discoList.add(new Disco("Days Go By", "The Offspring", "Columbia Records", 2012, 0));
        Disco.m_discoList.add(new Disco("Let the Bad Times Roll", "The Offspring", "Concord Records", 2021, 0));
        return Disco.m_discoList;
    }

    public ArrayList<Disco> getDiscoRedHot(){
        Disco.m_discoList.add(new Disco("Californication", "Red Hot Chili Peppers", "Warner", 1999, 0));
        Disco.m_discoList.add(new Disco("By the way", "Red Hot Chili Peppers", "Warner", 2002, 0));
        Disco.m_discoList.add(new Disco("Stadium Arcadium", "Red Hot Chili Peppers", "Warner", 2006, 0));
        Disco.m_discoList.add(new Disco("I'm with You", "Red Hot Chili Peppers", "Warrner", 2011, 0));
        Disco.m_discoList.add(new Disco("The Getaway", "Red Hot Chili Peppers", "Warrner", 2016, 0));
        Disco.m_discoList.add(new Disco("Unlimited Love", "Red Hot Chili Peppers", "Warrner", 2022, 0));
        return Disco.m_discoList;
    }

    public ArrayList<Disco> getDiscoPapa(){
        Disco.m_discoList.add(new Disco("Infest", "Papa Roach", "DreamWorks Records", 2000, 0));
        Disco.m_discoList.add(new Disco("Lovehatetragedy", "Papa Roach", "DreamWorks Records", 2002, 0));
        Disco.m_discoList.add(new Disco("Getting Away With Murder", "Papa Roach", "Geffen Records", 2004, 0));
        Disco.m_discoList.add(new Disco("The Paramour Sessions", "Papa Roach", "Geffen Records", 2006, 0));
        Disco.m_discoList.add(new Disco("Metamorphosis", "Papa Roach", "Interscope Records", 2009, 0));
        Disco.m_discoList.add(new Disco("The Connection", "Papa Roach", "Eleven Seven Music", 2012, 0));
        Disco.m_discoList.add(new Disco("F.E.A.R.", "Papa Roach", "Eleven Seven Music", 2015, 0));
        Disco.m_discoList.add(new Disco("Crooked Teeth", "Papa Roach", "Eleven Seven Music", 2017, 0));
        return Disco.m_discoList;
    }
    /*
    @Override
    public void itemClicked(long id)
    {
        Intent intent = new Intent(this, DiscoDetailActivity.class);
        intent.putExtra("discoId", id);
        startActivity(intent);
    }
     */

}
package com.example.fragment2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity implements GameListFragment.Listener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        GameData aux = new GameData("Horizon","...","2022","Sony");
        GameData.m_gameDataList.add(aux);
        aux = new GameData("Forza","...","2021","Micro");
        GameData.m_gameDataList.add(aux);

        setContentView(R.layout.activity_main);
    }

    @Override
    public void itemClicked(long id)
    {
        Intent intent = new Intent(this, GameDetailActivity.class);
        intent.putExtra("gameId", id);
        startActivity(intent);
    }
}
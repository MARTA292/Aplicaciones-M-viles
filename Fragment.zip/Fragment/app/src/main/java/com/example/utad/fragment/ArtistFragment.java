package com.example.utad.fragment;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.fragment.app.ListFragment;

public class ArtistFragment extends ListFragment {

    public ArtistFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        String names[] = new String[Artista.m_artistaList.size()];
        for (int i = 0; i < Artista.m_artistaList.size(); i++){
            names[i] = Artista.m_artistaList.get(i).m_nombre;
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(inflater.getContext(), android.R.layout.simple_list_item_1, names);
        setListAdapter(adapter);
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_artist, container, false);
    }

    static interface Listener{
        void itemClicked(long id);
    }

    private Listener m_listener;

    @Override
    public void onAttach(Context context){
        super.onAttach(context);
        m_listener = (Listener) context;
    }

    @Override
    public void onListItemClick (ListView list, View item, int position, long id){
        if (m_listener != null){
            m_listener.itemClicked(id);
        }
    }
}

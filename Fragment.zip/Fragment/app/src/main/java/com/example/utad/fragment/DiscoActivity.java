package com.example.utad.fragment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;

public class DiscoActivity extends AppCompatActivity implements MusicListFragment.Listener {
    private ArrayList<DiscoData> discos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        discos = getDiscoColdPlay();
        setContentView(R.layout.activity_main);
    }

    @Override
    public void itemClicked(long id)
    {
        Intent intent = new Intent(this, DiscoDetailActivity.class);
        intent.putExtra("discoId", id);
        startActivity(intent);
    }

    public ArrayList<DiscoData> getDiscoColdPlay(){
        DiscoData.m_discoDataList.add(new DiscoData("Parachutes", "ColdPlay", "Capitol Records", 2000, 0));
        DiscoData.m_discoDataList.add(new DiscoData("A Rush of Blood to the Head", "ColdPlay", "Capitol Records", 2002, 0));
        DiscoData.m_discoDataList.add(new DiscoData("X&Y", "ColdPlay", "Capitol Records", 2008, 0));
        DiscoData.m_discoDataList.add(new DiscoData("Mylo Xyloto", "ColdPlay", "Capitol Records", 2011, 0));
        DiscoData.m_discoDataList.add(new DiscoData("Ghost Stories", "ColdPlay", "Parlophone", 2014, 0));
        DiscoData.m_discoDataList.add(new DiscoData("Everyday Life", "ColdPlay", "Parlophone", 2021, 0));
        return DiscoData.m_discoDataList;
    }
}
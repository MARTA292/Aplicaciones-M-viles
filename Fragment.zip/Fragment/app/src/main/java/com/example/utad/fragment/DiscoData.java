package com.example.utad.fragment;

import java.util.ArrayList;

public class DiscoData {
    public String m_title;
    public String m_grupo;
    public String m_discografica;
    public int m_year;
    public int m_imagen;

    public static final ArrayList<DiscoData> m_discoDataList = new ArrayList<>();

    public DiscoData (String title, String grupo, String discografica, int year, int imagen) {
        m_title = title;
        m_grupo = grupo;
        m_discografica = discografica;
        m_year = year;
        m_imagen = imagen;
    }
}

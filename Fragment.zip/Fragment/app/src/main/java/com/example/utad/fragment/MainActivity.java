package com.example.utad.fragment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public ArrayList<Artista> artistas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        artistas = getArtistas();
        /*AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Log.d("Item Clicked", "0");
                    changeColdPlay(parent);
                }else if (position == 1) {
                    Log.d("Item Clicked", "1");
                    //changeOffspring(parent);
                }else if (position == 2) {
                    Log.d("Item Clicked", "2");
                    //changePapaRoach(parent);
                }else if (position == 3) {
                    Log.d("Item Clicked", "3");
                    //changePeppers(parent);
                }
            }
        };
        ((ListView)findViewById(R.id.artistaitemlist)).setOnItemClickListener(itemClickListener);
        */
    }

    public void itemClicked(long id) {
        Intent intent = new Intent(this, DiscoDetailActivity.class);
        intent.putExtra("discoId", id);
        startActivity(intent);
    }
    public ArrayList<Artista> getArtistas(){
        Artista.m_artistaList.add(new Artista("ColdPlay",0));
        Artista.m_artistaList.add(new Artista("The Offspring",0));
        Artista.m_artistaList.add(new Artista("Papa Roach",0));
        Artista.m_artistaList.add(new Artista("Red Hot Chili Peppers",0));
        return Artista.m_artistaList;
    }
}
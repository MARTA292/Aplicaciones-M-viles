package com.example.damo_listaartistas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class DiscoDetallesActivity extends AppCompatActivity {
    private FragmentManager fragmentManager;
    private long id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        long id = getIntent().getExtras().getLong("discoId");
        this.id=id;

        //androidx.appcompat.widget.Toolbar tool = findViewById(R.id.toolbar);
        //setSupportActionBar(tool);

        setContentView(R.layout.activity_disco_detalles);
        fragmentManager = getSupportFragmentManager();
        DiscoDetallesFragment fragment = (DiscoDetallesFragment) fragmentManager.findFragmentById(R.id.disco_detalles_fragment);
        setTitle(Disco.m_discoList.get((int)id).m_title);
        fragment.setDisco(id);
    }

    public void share(View v){
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_EMAIL, new
                String[]{"direccion@ext.live.u-tad.es"});
        intent.putExtra(Intent.EXTRA_SUBJECT, "Escucha este álbum");
        intent.putExtra(Intent.EXTRA_TEXT, "Título: " + Disco.m_discoList.get((int)id).m_title +
                "\nArtista: " + Disco.m_discoList.get((int)id).m_grupo +
                "\nDiscografía:  " + Disco.m_discoList.get((int)id).m_discografica +
                "\nAño de lanzamiento: " + Disco.m_discoList.get((int)id).m_year);

        intent.setType("message/rfc822");
        startActivity(intent);
    }
}
package com.example.damo_listaartistas;

import java.util.ArrayList;

public class Disco {
    public String m_title;
    public String m_grupo;
    public String m_discografica;
    public int m_year;
    public int m_imagen; //R.drawable.nombreimagen --> esto es un número

    public static final ArrayList<Disco> m_discoList = new ArrayList<>();

    public Disco (String title, String grupo, String discografica, int year, int imagen) {
        m_title = title;
        m_grupo = grupo;
        m_discografica = discografica;
        m_year = year;
        m_imagen = imagen;
    }
}
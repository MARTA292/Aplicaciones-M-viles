package com.example.damo_listaartistas;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class DiscoAdapter extends ArrayAdapter<Disco> {
    public DiscoAdapter(Context context, ArrayList<Disco> data) {
        super(context, 0, data);
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Disco data = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.lista_con_fotos, parent, false);
        }
        ImageView disco_img = (ImageView) convertView.findViewById(R.id.image_row);
        TextView disco_name = (TextView) convertView.findViewById(R.id.text_row);
        disco_img.setImageResource(data.m_imagen);
        disco_name.setText(data.m_title);
        return convertView;
    }
}

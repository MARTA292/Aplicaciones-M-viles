package com.example.damo_listaartistas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements ArtistListFragment.Listener {
    private ArrayList<Artista> artistas;
    //private ArrayList<Disco> discos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        artistas = getArtistas();
        setContentView(R.layout.activity_main);
        /*
        ArrayAdapter<Artista> adapter = new ArrayAdapter<Artista>(this, R.layout.lista_con_fotos, artistas);
        ListView videogameList = findViewById(R.id.artist_list_fragment);
        videogameList.setAdapter(adapter); */

        ArtistaAdapter adapter = new ArtistaAdapter(this, artistas);
        ListView artistList = findViewById(R.id.artist_list_fragment);
        artistList.setAdapter(adapter);
    }

    @Override
    public void itemClicked(long id) {
        Intent intent = new Intent(this, DiscoActivity.class);
        if (id == 0) {
            Log.d("Item Clicked", "0");
            //discos = getDiscoColdPlay();
        } else if (id == 1) {
            Log.d("Item Clicked", "1");
            //discos = getDiscoOffSpring();
        } else if (id == 2) {
            Log.d("Item Clicked", "2");
            //discos = getDiscoRedHot();
        } else if (id == 3) {
            Log.d("Item Clicked", "3");
            //discos = getDiscoPapa();
        }
        intent.putExtra("artistaId", id);
        startActivity(intent);
    }

    public ArrayList<Artista> getArtistas(){
        Artista.m_artistaList.clear();
        Artista.m_artistaList.add(new Artista("ColdPlay",R.drawable.coldplay));
        Artista.m_artistaList.add(new Artista("The Offspring",R.drawable.smash));
        Artista.m_artistaList.add(new Artista("Papa Roach",R.drawable.californication));
        Artista.m_artistaList.add(new Artista("Red Hot Chili Peppers",R.drawable.infest));
        return Artista.m_artistaList;
    }
}
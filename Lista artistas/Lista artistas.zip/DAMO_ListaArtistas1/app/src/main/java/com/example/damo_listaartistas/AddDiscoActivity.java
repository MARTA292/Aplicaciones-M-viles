package com.example.damo_listaartistas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class AddDiscoActivity extends AppCompatActivity{
    private ArrayList<Disco> discosActuales;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_disco);

        //discosActuales = (ArrayList<Disco>) getIntent().getExtras().getSerializable("listaDiscos");
        /*Button btnForm = findViewById(R.id.btn_add);
        btnForm.setOnClickListener(this);*/
    }

    public void onClick(View v){
        EditText aux = findViewById(R.id.input_titulo);
        String disco = aux.getText().toString();
        aux = findViewById(R.id.input_artista);
        String artista = aux.getText().toString();
        aux = findViewById(R.id.input_discografica);
        String discografica = aux.getText().toString();
        aux = findViewById(R.id.input_año);
        int year;
        try{
            year = Integer.parseInt(aux.getText().toString());
        }catch (Exception e){
            year = 2020;
        }

        discosActuales.add(new Disco(disco, artista, discografica, year, R.drawable.album));
        Intent intent = new Intent(this, DiscoActivity.class);
        //intent.putExtra("listaActualizada", discosActuales);
        startActivity(intent);
        finish();
    }
}
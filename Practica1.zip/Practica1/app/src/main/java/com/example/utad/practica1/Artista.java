package com.example.utad.practica1;

public class Artista {
    private String nombre;
    private String imagen;

    public Artista(String nombre, String imagen) {
        this.nombre = nombre;
        this.imagen = imagen;
    }

    public String getNombre() {
        return nombre;
    }

    public String getImagen() {
        return imagen;
    }

}

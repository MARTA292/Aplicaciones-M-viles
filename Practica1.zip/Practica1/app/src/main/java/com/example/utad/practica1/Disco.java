package com.example.utad.practica1;

public class Disco {
    private String titulo;
    private String artista;
    private String discografica;
    private int year;
    private String imagen;

    public Disco(String titulo, String artista, String discografica, int year, String imagen) {
        this.titulo = titulo;
        this.artista = artista;
        this.discografica = discografica;
        this.year = year;
        this.imagen = imagen;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getArtista() {
        return artista;
    }

    public String getDiscografica() {
        return discografica;
    }

    public int getYear() {
        return year;
    }

    public String getImagen() {
        return imagen;
    }
}

package com.example.utad.practica1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import java.util.ArrayList;

public class Discos {
    private ArrayList<Disco> discos;
    public ArrayList<Artista> artistas;
    public Discos(){

    }

    public ArrayList<Artista> getArtistas(){
        artistas = new ArrayList<>();
        artistas.add(new Artista("ColdPlay","0"));
        artistas.add(new Artista("The Offspring","0"));
        artistas.add(new Artista("Papa Roach","0"));
        artistas.add(new Artista("Red Hot Chili Peppers","0"));
        return artistas;
    }

    public ArrayList<Disco> getDiscoColdPlay(){
        discos = new ArrayList<>();
        discos.add(new Disco("Parachutes", "ColdPlay", "Capitol Records", 2000, "0"));
        discos.add(new Disco("A Rush of Blood to the Head", "ColdPlay", "Capitol Records", 2002, "0"));
        discos.add(new Disco("X&Y", "ColdPlay", "Capitol Records", 2008, "0"));
        discos.add(new Disco("Mylo Xyloto", "ColdPlay", "Capitol Records", 2011, "0"));
        discos.add(new Disco("Ghost Stories", "ColdPlay", "Parlophone", 2014, "0"));
        discos.add(new Disco("Everyday Life", "ColdPlay", "Parlophone", 2021, "0"));
        return discos;
    }
}

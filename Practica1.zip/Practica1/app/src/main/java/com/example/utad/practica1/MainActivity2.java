package com.example.utad.practica1;

import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    //Discos discos = new Discos();
    //ArrayList<Disco> discoColdPlay = discos.getDiscoColdPlay();
    String[] discosColdPlay = new String[]{"Parachutes", "A Rush of Blood to the Head", "X&Y", "Mylo Xyloto", "Ghost Stories", "Everyday Life"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listdiscos);
        //((ListView)findViewById(R.id.artistasitemlist)).setOnItemClickListener(itemClickListener);
        //discoColdPlay.forEach(discosColdPlay.add(discoColdPlay.getTitulo());
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.discos_item, discosColdPlay);
        ((ListView)findViewById(R.id.discositemlist)).setAdapter(adapter);
    }
}

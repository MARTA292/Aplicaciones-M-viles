package com.example.utad.tresenraya;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    boolean isPlayerOne = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void getButton(View v) {
        String aux = ((Button)v).getText().toString();
        if(aux.equals("-")){
            if(isPlayerOne){
                ((Button)v).setText("X");
            }else{
                ((Button)v).setText("O");
            }
        }if(isPlayerOne){isPlayerOne = false;}
        else{isPlayerOne=true;}
    }

}
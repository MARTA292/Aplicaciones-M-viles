package com.example.utad.listview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0)
                    Log.d("Item Clicked", "0");
                else if (position == 1)
                    Log.d("Item Clicked", "1");
                else if (position == 2)
                    Log.d("Item Clicked", "2");
            }
        };
        ((ListView)findViewById(R.id.videogameitemlist)).setOnItemClickListener(itemClickListener);
    }
    public void changeActivity(View v){
        Intent IEjemplo = new Intent(this, ListView2.class);
        startActivity(IEjemplo);
    }
}
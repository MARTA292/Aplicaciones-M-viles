package com.example.utad.listview;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class ListView2  extends AppCompatActivity {
    String[] videoconsoles = new String[]{"XboxOne", "PS4", "Switch", "Xbox 360"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listview2);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.videoconsole_item, videoconsoles);
        ((ListView)findViewById(R.id.videogameitemlist)).setAdapter(adapter);
    }
}

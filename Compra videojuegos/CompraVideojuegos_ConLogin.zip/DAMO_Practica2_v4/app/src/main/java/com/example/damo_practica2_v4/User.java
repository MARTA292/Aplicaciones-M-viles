package com.example.damo_practica2_v4;

import java.util.ArrayList;

public class User {
    public int id;
    public String name;
    public String password;

    public static ArrayList<User> m_user = new ArrayList<User>();

    public User(int id, String name, String password) {
        this.id = id;
        this.name = name;
        this.password = password;
    }
}

package com.example.damo_practica2_v4;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class RegistroActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;

    private Context context;

    private SQLiteDatabase database;
    private UserHelper userHelper;
    private Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.registroButton);

        userHelper = new UserHelper(this, "gamesdatabase", 1);
        database = userHelper.getReadableDatabase();
        Cursor cursor = database.query(SchemeLoginDB.TAB_USER,
                new String[]{SchemeLoginDB.USER_ID, SchemeLoginDB.USER_NAME, SchemeLoginDB.USER_PASSWORD},
                null,
                null,
                null, null, null);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = usernameEditText.toString();
                String password = passwordEditText.toString();
                //String query = "INSERT INTO USUARIOS (NAME, PASSWORD) VALUES "+ name + ", " + password;
                //cursor = database.rawQuery(query, null);
                database.execSQL("INSERT INTO "+SchemeLoginDB.TAB_USER+ " ("+ SchemeLoginDB.USER_NAME + "," +  SchemeLoginDB.USER_PASSWORD +") VALUES "+ usernameEditText.toString() + ", " + passwordEditText.toString());
//                ContentValues userData = new ContentValues();
//                userData.put(SchemeLoginDB.USER_NAME, name);
//                userData.put(SchemeLoginDB.USER_PASSWORD, password);
//                database.insert(SchemeLoginDB.TAB_USER, null, userData);
                register();
            }
        });
    }

    public void register(){
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
    }
}
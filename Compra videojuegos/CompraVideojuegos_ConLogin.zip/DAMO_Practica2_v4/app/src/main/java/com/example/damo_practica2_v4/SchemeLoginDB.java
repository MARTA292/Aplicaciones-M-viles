package com.example.damo_practica2_v4;

public interface SchemeLoginDB {
    int VERSION = 1;
    String DB_NAME = "SHOPGAMES";
    String TAB_USER = "USUARIOS";
    String USER_ID = "_id";
    String USER_NAME = "NAME";
    String USER_PASSWORD = "PASSWORD";
}

package com.example.damo_practica2_v4;

public enum TipoConsola {
    Todos,
    XBOX,
    PS4,
    PC,
}

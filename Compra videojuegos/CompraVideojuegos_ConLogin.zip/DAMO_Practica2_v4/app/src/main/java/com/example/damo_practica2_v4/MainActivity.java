package com.example.damo_practica2_v4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton, registerButton;

    private SQLiteDatabase database;
    private UserHelper userHelper;
    private Cursor cursor;

    private ArrayList<User> usuarios = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usuarios = new ArrayList<>();

        usernameEditText = findViewById(R.id.activity_main_usernameEditText);
        passwordEditText = findViewById(R.id.activity_main_passwordEditText);
        loginButton = findViewById(R.id.activity_main_loginButton);
        registerButton = findViewById(R.id.registroButton);

//        userHelper = new UserHelper(this, "gamesdatabase", 1);
//        database = userHelper.getReadableDatabase();
//        Cursor cursor = database.query(SchemeLoginDB.TAB_USER,
//                new String[]{SchemeLoginDB.USER_ID, SchemeLoginDB.USER_NAME, SchemeLoginDB.USER_PASSWORD},
//                null,
//                null,
//                null, null, null);
//        fillUsers();
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (usernameEditText.getText().length() > 0 && passwordEditText.getText().length() > 0) {
                    String toastMessage = "Username: " + usernameEditText.getText().toString() + ", Password: " + passwordEditText.getText().toString();
                    Toast.makeText(getApplicationContext(), toastMessage, Toast.LENGTH_SHORT).show();
                    /*for(int i=0; i<usuarios.size(); i++){
                        if(usernameEditText.getText().equals(usuarios.get(i).name) && passwordEditText.getText().equals(usuarios.get(i).password)){
                            Log.d("Login: ","Usuario correcto");
                            login();
                        }
                    }*/
                    //Toast.makeText(getApplicationContext(), "User or password wrong", Toast.LENGTH_SHORT).show();
                    login();
                } else {
                    String toastMessage = "Username or Password are not populated";
                    Toast.makeText(getApplicationContext(), toastMessage, Toast.LENGTH_SHORT).show();
                }
            }
        });
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                register();
            }
        });
    }
    public void fillUsers(){
        usuarios.clear();
        String query = "SELECT * FROM "+ SchemeLoginDB.TAB_USER;
        cursor = database.rawQuery(query, null);
        if (cursor.getCount() > 0) {
            // Situo en la primera posición
            cursor.moveToFirst();
            int idIndex = cursor.getColumnIndex(SchemeLoginDB.USER_ID);
            int nameIndex = cursor.getColumnIndex(SchemeLoginDB.USER_NAME);
            int companyIndex = cursor.getColumnIndex(SchemeLoginDB.USER_PASSWORD);

            String name, password;
            int id;
            do {
                id = cursor.getInt(idIndex);
                name = cursor.getString(nameIndex);
                password = cursor.getString(companyIndex);
                usuarios.add(new User(id, name, password));
            }while (cursor.moveToNext());
        }
        database.close();
    }
    private void login(){
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
    }
    private void register(){
        Intent intent = new Intent(this, RegistroActivity.class);
        startActivity(intent);
    }

}
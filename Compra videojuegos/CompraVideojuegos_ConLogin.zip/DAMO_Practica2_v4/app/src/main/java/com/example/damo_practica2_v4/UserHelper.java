package com.example.damo_practica2_v4;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class UserHelper extends SQLiteOpenHelper {
    public UserHelper(Context context, String name, int version) {
        super(context, name, null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE " + SchemeLoginDB.TAB_USER + " ("
                + SchemeLoginDB.USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + SchemeLoginDB.USER_NAME + " TEXT, "
                + SchemeLoginDB.USER_PASSWORD + " TEXT); ");

        addUser(sqLiteDatabase, "admin","admin");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) { }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        super.onDowngrade(db, oldVersion, newVersion);
    }

    public static void addUser (SQLiteDatabase db, String name, String password){
        ContentValues userData = new ContentValues();
        userData.put(SchemeLoginDB.USER_NAME, name);
        userData.put(SchemeLoginDB.USER_PASSWORD, password);
        db.insert(SchemeLoginDB.TAB_USER, null, userData);
    }

}

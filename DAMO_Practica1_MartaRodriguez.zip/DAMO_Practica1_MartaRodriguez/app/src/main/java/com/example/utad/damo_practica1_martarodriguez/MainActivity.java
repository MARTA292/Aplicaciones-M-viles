package com.example.utad.damo_practica1_martarodriguez;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Log.d("Item Clicked", "0");
                    changeColdPlay(parent);
                }else if (position == 1) {
                    Log.d("Item Clicked", "1");
                    //changeOffspring(parent);
                }else if (position == 2) {
                    Log.d("Item Clicked", "2");
                    //changePapaRoach(parent);
                }else if (position == 3) {
                    Log.d("Item Clicked", "3");
                    //changePeppers(parent);
                }
            }
        };
        ((ListView)findViewById(R.id.artistaitemlist)).setOnItemClickListener(itemClickListener);
    }
    public void changeColdPlay(View v){
        Intent IEjemplo = new Intent(this, MainActivity2.class);
        startActivity(IEjemplo);
    }/*
    public void changeOffspring(View v){
        Intent IEjemplo = new Intent(this, MainActivity3.class);
        startActivity(IEjemplo);
    }
    public void changePapaRoach(View v){
        Intent IEjemplo = new Intent(this, MainActivity4.class);
        startActivity(IEjemplo);
    }
    public void changePeppers(View v){
        Intent IEjemplo = new Intent(this, MainActivity5.class);
        startActivity(IEjemplo);
    }*/
}
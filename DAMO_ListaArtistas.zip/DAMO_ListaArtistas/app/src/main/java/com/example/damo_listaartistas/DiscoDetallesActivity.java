package com.example.damo_listaartistas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;

public class DiscoDetallesActivity extends AppCompatActivity {
    private FragmentManager fragmentManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        long id = getIntent().getExtras().getLong("discoId");
        setContentView(R.layout.activity_disco_detalles);
        fragmentManager = getSupportFragmentManager();
        DiscoDetallesFragment fragment = (DiscoDetallesFragment) fragmentManager.findFragmentById(R.id.disco_detalles_fragment);
        fragment.setDisco(id);
    }
}
package com.example.damo_listaartistas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements ArtistListFragment.Listener {
    private ArrayList<Artista> artistas;
    //private ArrayList<Disco> discos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        artistas = getArtistas();
        setContentView(R.layout.activity_main);
    }
    @Override
    public void itemClicked(long id)
    {
        Intent intent = new Intent(this, DiscoActivity.class);
        if (id == 0) {
            Log.d("Item Clicked", "0");
            //discos = getDiscoColdPlay();
        }else if (id == 1) {
            Log.d("Item Clicked", "1");
            //discos = getDiscoOffSpring();
        }else if (id == 2) {
            Log.d("Item Clicked", "2");
            //discos = getDiscoRedHot();
        }else if (id == 3) {
            Log.d("Item Clicked", "3");
            //discos = getDiscoPapa();
        }
        intent.putExtra("artistaId", id);
        startActivity(intent);
    }
    public ArrayList<Artista> getArtistas(){
        Artista.m_artistaList.add(new Artista("ColdPlay",R.drawable.coldplay));
        Artista.m_artistaList.add(new Artista("The Offspring",R.drawable.californication));
        Artista.m_artistaList.add(new Artista("Papa Roach",R.drawable.smash));
        Artista.m_artistaList.add(new Artista("Red Hot Chili Peppers",R.drawable.infest));
        return Artista.m_artistaList;
    }
}
package com.example.damo_listaartistas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

public class DiscoActivity extends AppCompatActivity implements DiscoListFragment.Listener{
    private ArrayList<Disco> discos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        long idArtista = getIntent().getExtras().getLong("artistaId");
        if (idArtista == 0) {
            Log.d("Artista", "Coldplay");
            discos = getDiscoColdPlay();
        }else if (idArtista == 1) {
            Log.d("Artista", " OffSpring");
            discos = getDiscoOffSpring();
        }else if (idArtista == 2) {
            Log.d("Artista", "RedHot");
            discos = getDiscoRedHot();
        }else if (idArtista == 3) {
            Log.d("Artista", "Papa");
            discos = getDiscoPapa();
        }
        setContentView(R.layout.activity_disco);
    }

    @Override
    public void itemClicked(long id)
    {
        Intent intent = new Intent(this, DiscoDetallesActivity.class);
        if (id == 0) {
            Log.d("Item Clicked", "0");
        }else if (id == 1) {
            Log.d("Item Clicked", "1");
        }else if (id == 2) {
            Log.d("Item Clicked", "2");
        }else if (id == 3) {
            Log.d("Item Clicked", "3");
        }
        intent.putExtra("discoId", id);
        startActivity(intent);
    }


    public ArrayList<Disco> getDiscoColdPlay(){
        Disco.m_discoList.add(new Disco("Parachutes", "ColdPlay", "Capitol Records", 2000, R.drawable.parachutes));
        Disco.m_discoList.add(new Disco("A Rush of Blood to the Head", "ColdPlay", "Capitol Records", 2002, R.drawable.rush_of_blood));
        Disco.m_discoList.add(new Disco("X&Y", "ColdPlay", "Capitol Records", 2008, R.drawable.xy));
        Disco.m_discoList.add(new Disco("Mylo Xyloto", "ColdPlay", "Capitol Records", 2011, R.drawable.mylo_xyloto));
        Disco.m_discoList.add(new Disco("Ghost Stories", "ColdPlay", "Parlophone", 2014, R.drawable.ghoststories));
        Disco.m_discoList.add(new Disco("Everyday Life", "ColdPlay", "Parlophone", 2021, R.drawable.everyday_life));
        return Disco.m_discoList;
    }

    public ArrayList<Disco> getDiscoOffSpring(){
        Disco.m_discoList.add(new Disco("Smash", "The Offspring", "Epitaph Records", 1994, R.drawable.smash));
        Disco.m_discoList.add(new Disco("Ixnay on the Hombre", "The Offspring", "Columbia Records", 1997, R.drawable.smash));
        Disco.m_discoList.add(new Disco("Americana", "The Offspring", "Columbia Records", 1998, R.drawable.smash));
        Disco.m_discoList.add(new Disco("Splinter", "The Offspring", "Columbia Records", 2003, R.drawable.smash));
        Disco.m_discoList.add(new Disco("Rise and Fall, Rage and Grace", "The Offspring", "Columbia Records", 2008, R.drawable.smash));
        Disco.m_discoList.add(new Disco("Days Go By", "The Offspring", "Columbia Records", 2012, R.drawable.smash));
        Disco.m_discoList.add(new Disco("Let the Bad Times Roll", "The Offspring", "Concord Records", 2021, R.drawable.smash));
        return Disco.m_discoList;
    }

    public ArrayList<Disco> getDiscoRedHot(){
        Disco.m_discoList.add(new Disco("Californication", "Red Hot Chili Peppers", "Warner", 1999, R.drawable.californication));
        Disco.m_discoList.add(new Disco("By the way", "Red Hot Chili Peppers", "Warner", 2002, R.drawable.californication));
        Disco.m_discoList.add(new Disco("Stadium Arcadium", "Red Hot Chili Peppers", "Warner", 2006, R.drawable.californication));
        Disco.m_discoList.add(new Disco("I'm with You", "Red Hot Chili Peppers", "Warrner", 2011, R.drawable.californication));
        Disco.m_discoList.add(new Disco("The Getaway", "Red Hot Chili Peppers", "Warrner", 2016, R.drawable.californication));
        Disco.m_discoList.add(new Disco("Unlimited Love", "Red Hot Chili Peppers", "Warrner", 2022, R.drawable.californication));
        return Disco.m_discoList;
    }

    public ArrayList<Disco> getDiscoPapa(){
        Disco.m_discoList.add(new Disco("Infest", "Papa Roach", "DreamWorks Records", 2000, R.drawable.infest));
        Disco.m_discoList.add(new Disco("Lovehatetragedy", "Papa Roach", "DreamWorks Records", 2002, R.drawable.infest));
        Disco.m_discoList.add(new Disco("Getting Away With Murder", "Papa Roach", "Geffen Records", 2004, R.drawable.infest));
        Disco.m_discoList.add(new Disco("The Paramour Sessions", "Papa Roach", "Geffen Records", 2006, R.drawable.infest));
        Disco.m_discoList.add(new Disco("Metamorphosis", "Papa Roach", "Interscope Records", 2009, R.drawable.infest));
        Disco.m_discoList.add(new Disco("The Connection", "Papa Roach", "Eleven Seven Music", 2012, R.drawable.infest));
        Disco.m_discoList.add(new Disco("F.E.A.R.", "Papa Roach", "Eleven Seven Music", 2015, R.drawable.infest));
        Disco.m_discoList.add(new Disco("Crooked Teeth", "Papa Roach", "Eleven Seven Music", 2017, R.drawable.infest));
        return Disco.m_discoList;
    }
}
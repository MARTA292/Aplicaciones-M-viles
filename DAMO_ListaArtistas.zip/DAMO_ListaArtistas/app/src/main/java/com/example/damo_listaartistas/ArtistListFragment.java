package com.example.damo_listaartistas;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.ListFragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class ArtistListFragment extends ListFragment {

    public ArtistListFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        /*String names[] = new String[Artista.m_artistaList.size()];
        for (int i = 0; i < Artista.m_artistaList.size(); i++){
            names[i] = Artista.m_artistaList.get(i).m_nombre;
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(inflater.getContext(), android.R.layout.simple_list_item_1, names);
        setListAdapter(adapter);*/
        for (int i = 0; i < Artista.m_artistaList.size(); i++){
            View v = getView();
            ((ImageView)v.findViewById(R.id.imagen_fila)).setImageResource(Artista.m_artistaList.get(i).m_imagen);
            ((TextView)v.findViewById(R.id.nombre_fila)).setText(Artista.m_artistaList.get(i).m_nombre);
        }

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_artist_list, container, false);
    }

    static interface Listener{
        void itemClicked(long id);
    }

    private Listener m_listener;

    @Override
    public void onAttach(Context context){
        super.onAttach(context);
        m_listener = (Listener) context;
    }
    @Override
    public void onListItemClick (ListView list, View item, int position, long id){
        if (m_listener != null){
            m_listener.itemClicked(id);
        }
    }
}
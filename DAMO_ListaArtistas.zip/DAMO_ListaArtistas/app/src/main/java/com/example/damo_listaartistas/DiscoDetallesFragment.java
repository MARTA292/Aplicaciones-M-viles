package com.example.damo_listaartistas;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class DiscoDetallesFragment extends Fragment {
    private long m_discoId;

    public DiscoDetallesFragment() { }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_disco_detalles, container, false);
    }
    @Override
    public void onStart(){
        super.onStart();
    }

    public void setDisco(long id){
        m_discoId = id;
        View v = getView();
        Log.d("id", Long.toString(id));
        if (v != null){
            ((ImageView)v.findViewById(R.id.imageView)).setImageResource(Disco.m_discoList.get((int)m_discoId).m_imagen);
            ((TextView)v.findViewById(R.id.titulo)).setText(Disco.m_discoList.get((int)m_discoId).m_title);
            ((TextView)v.findViewById(R.id.grupo)).setText(Disco.m_discoList.get((int)m_discoId).m_grupo);
            ((TextView)v.findViewById(R.id.year)).setText(String.valueOf(Disco.m_discoList.get((int)m_discoId).m_year));
            ((TextView)v.findViewById(R.id.discografica)).setText(Disco.m_discoList.get((int)m_discoId).m_discografica);
        }
    }
}
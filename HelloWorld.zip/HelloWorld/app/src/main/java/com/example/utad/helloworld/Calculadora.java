package com.example.utad.helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Calculadora extends AppCompatActivity {
    Integer numero1;
    Integer numero2;
    char operacion;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.buttonresult);
    }

    public void getButton (View v){
        if(((Button)v).getText().toString().equals("+")){
            operacion = '+';
        }else if(((Button)v).getText().toString().equals("-")){
            operacion = '-';
        }else if(((Button)v).getText().toString().equals("*")){
            operacion = '*';
        }else if(((Button)v).getText().toString().equals("/")){
            operacion = '/';
        }else if(((Button)v).getText().toString().equals("=")){
            mostrar();
        }else if(numero1 == null){
            numero1 = Integer.parseInt(((Button)v).getText().toString());
            button.setText(numero1.toString());
        }else if (numero1 != null && numero2 == null) {
            numero2 = Integer.parseInt(((Button)v).getText().toString());
            button.setText(numero2.toString());
        }
    }
    protected Integer suma(Integer num1, Integer num2) { return (num1+num2); }
    protected Integer resta(Integer num1, Integer num2) { return (num1-num2); }
    protected Integer producto(Integer num1, Integer num2) { return (num1*num2); }
    protected Integer division(Integer num1, Integer num2) {return (num1/num2);}

    protected void mostrar(){
        if(operacion == '+'){
            button.setText(suma(numero1, numero2).toString());
        }else if(operacion == '-'){
            button.setText(resta(numero1, numero2).toString());
        }else if(operacion == '*'){
            button.setText(producto(numero1, numero2).toString());
        }else if(operacion == '/') {
            button.setText(division(numero1, numero2).toString());
        }
    }




}
package com.example.utad.mainactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    TextView m_text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        m_text = findViewById(R.id.textView);
        Intent intent = getIntent();
        String value = intent.getStringExtra("To");
        m_text.setText(value);

        m_text = findViewById(R.id.textView5);
        Intent intent1 = getIntent();
        String value1 = intent.getStringExtra("Subject");
        m_text.setText(value);

        m_text = findViewById(R.id.textView6);
        Intent intent2 = getIntent();
        String value2 = intent.getStringExtra("Texto");
        m_text.setText(value);
    }
}
package com.example.utad.mainactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

//Ejercicio clase 2 - 14/02/2022
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void ChangeActivity(View v){
        //((Button)v).setText();
        //((Button)findViewById(R.id.button)).setText();
        /*
        Intent intent = new Intent(this, MainActivity2.class);
        intent.putExtra("message", "hola");
        startActivities(intent);*/

        String destinatario = ((EditText)findViewById(R.id.editTextTextEmailAddress)).getText().toString();
        String asunto = ((EditText)findViewById(R.id.editTextTextPersonName2)).getText().toString();
        String contenido = ((EditText)findViewById(R.id.editTextTextMultiLine)).getText().toString();

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_EMAIL, new String[] { destinatario });
        intent.putExtra(Intent.EXTRA_SUBJECT, asunto);
        intent.putExtra(Intent.EXTRA_TEXT, contenido);
        startActivity(intent);
    }
}